/**
 * 
 */
package utils.libraries.common;

import java.util.List;
import org.apache.log4j.Logger;
import org.testng.asserts.Assertion;
import org.testng.asserts.IAssert;
import org.testng.collections.Lists;

/**
 * @author varavee
 *
 */
public class CustomAssertion extends Assertion {

	// LinkedHashMap to preserve the order
	public List<String> m_messages = Lists.newArrayList();

	Logger log = Logger.getLogger(this.getClass());


	@Override
	public void onBeforeAssert(IAssert a) {

		m_messages.add(" Before Assert :: The Excected Result is::" + a.getExpected());
	}

	@Override
	public void onAssertFailure(IAssert a) {

		m_messages.add("\n" + ":: On Assert Failure :: The Excected Result is::" + a.getExpected() + "\n"
				+ ":: but the Actual Result is::" + a.getActual() + "\n" + ":: The Erro log is ::" + a.getMessage());
		getMessages();
	}

	public void getMessages() {
		log.info(m_messages.toString());
	}

}
