package utils.libraries.common;

import com.vimalselvam.cucumber.listener.Reporter;
import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.api.cucumber.stepdfn.ApplicationStepDfn;
import com.api.cucumber.stepdfn.WebDriverTestBase;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

/**
 * @author varavee
 *
 */

/**
 * @author varavee
 *
 */

public class Helper extends WebDriverTestBase {


	static Map<String,Object> testcasedata = ApplicationStepDfn.testcasedata; 



	public static void selectByVisibleText(WebElement element, String text, Map<String, Object> testcasedata) throws IOException {
		try {
			Select dropdown = new Select(element);
			dropdown.selectByVisibleText(String.valueOf(testcasedata.get(text)));
			takeScreenShotForEachTest(testcasedata);

		} catch (Exception e) {
			getScreenshotAs("Screenshot");
			Assert.fail("Failed  to Select the value: " + text);

		}
	}

	public static void selectDropdownByValue(WebElement element, String inputData, Map<String, Object> testcasedata) throws IOException {
		try {
			Select dropdown = new Select(element);
			dropdown.selectByValue(inputData);
			takeScreenShotForEachTest(testcasedata);

		} catch (Exception e) {
			getScreenshotAs("Screenshot");
			Assert.fail("Failed  to Select the value: " + inputData);

		}
	}

	public boolean isElementPresentClick(WebElement element, Map<String, Object> testcasedata) throws IOException {
		getDriver().manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
		try {
			element.click();
			takeScreenShotForEachTest(testcasedata);

			return true;
		} catch (Exception e) {
			getScreenshotAs("Screenshot");

			return false;
		}
	}

	public boolean isElementPresentSendkeys(WebElement element, String inputData, Map<String, Object> testcasedata) throws IOException {
		getDriver().manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
		try {
			element.sendKeys(String.valueOf(testcasedata.get(inputData)));
			takeScreenShotForEachTest(testcasedata);
			return true;
		} catch (Exception e) {
			getScreenshotAs("Screenshot");
			return false;
		}
	}

	public static boolean isElementPresent(WebElement element, Map<String, Object> testcasedata) throws IOException {

		try {
			element.isDisplayed();
			takeScreenShotForEachTest(testcasedata);

			return true;
		} catch (Exception e) {
			getScreenshotAs("Screenshot");

			return false;
		}
	}

	public static String getText(WebElement element, Map<String, Object> testcasedata) throws IOException {

		try {

			return element.getText();

		} catch (Exception e) {
			getScreenshotAs("Screenshot");

			return e.getMessage();
		}
	}

	public static void selectDropDown(WebElement element, String value, Map<String, Object> testcasedata) throws IOException {

		try {
			Select dropdown = new Select(element);
			dropdown.selectByVisibleText(String.valueOf(testcasedata.get(value)));
			takeScreenShotForEachTest(testcasedata);

		} catch (Exception e) {
			getScreenshotAs("Screenshot");

			Assert.fail("Failed to select the value: " + value);
		}
	}

	public static void clearAndEnterText(WebElement element, String value) throws IOException {
		try {

			element.clear();
			if (!value.equalsIgnoreCase("null"))
				element.sendKeys(value);
			takeScreenShotForEachTest(testcasedata);
		} catch (Exception e) {
			getScreenshotAs("Screenshot");
			Assert.fail("Unable to enter the value: " + value);
		}
	}

	public static void selectDropDownByValue(WebElement element, String inputData) throws IOException {

		try {

			Select dropdown = new Select(element);
			dropdown.selectByValue(inputData);
			takeScreenShotForEachTest(testcasedata);
		} catch (Exception e) {
			getScreenshotAs("Screenshot");
			Assert.fail("Unable to select the value: " + inputData);
		}
	}

	public static void deselectDropDown(WebElement element) throws IOException {
		try {
			Select dropdown = new Select(element);
			dropdown.deselectAll();
			takeScreenShotForEachTest(testcasedata);
		} catch (Exception e) {
			getScreenshotAs("Screenshot");
			Assert.fail("Element not found: " + element);

		}
	}

	public static void compareMessage(WebElement element, String ExpectedErrormsg) throws IOException {
		String actualmsg = element.getText();
		if (!actualmsg.equalsIgnoreCase(ExpectedErrormsg)) {
			getScreenshotAs("Screenshot");
			Assert.fail("Maintenance is not done as expected message is " + ExpectedErrormsg
					+ " Actual Message is mis-matched : " + actualmsg);
		}
	}

	public static void enterText(WebElement element, String text, Map<String, Object> testcasedata) throws IOException {
		try {
			element.clear();
			element.sendKeys(String.valueOf(testcasedata.get(text)));
			takeScreenShotForEachTest(testcasedata);
		} catch (Exception e) {
			getScreenshotAs("Screenshot");
			Assert.fail("Unable to enter the text because of the exception " + e);
		}
	}

	public static void click(WebElement element, Map<String, Object> testcasedata) throws IOException {
		try {
			element.click();
			takeScreenShotForEachTest(testcasedata);
		} catch (Exception e) {
			getScreenshotAs("Screenshot");
			Assert.fail("Unable to click because of the exception " + e);
		}
	}

	public static String dateFormat(String systemdate, String month) {
		String resultDate = null;
		try {
			String sdate = systemdate;
			SimpleDateFormat df = new SimpleDateFormat("yyyy/MM/dd");
			Date date = df.parse(sdate); // conversion from String
			int mon = Integer.parseInt(month);
			Calendar cal = GregorianCalendar.getInstance();
			cal.setTime(date);
			cal.add(GregorianCalendar.MONTH, mon); // date manipulation
			System.out.println("result: " + df.format(cal.getTime())); // conversion to String
			resultDate = df.format(cal.getTime());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return resultDate;
	}

	public static String dateAddition(String systemdate, int monthCount) {
		String Maturitydate = null;
		try {
			String sdate = systemdate;
			SimpleDateFormat df = new SimpleDateFormat("yyyy/MM/dd");
			Date date = df.parse(sdate); // conversion from String
			Calendar cal = GregorianCalendar.getInstance();
			cal.setTime(date);
			cal.add(GregorianCalendar.MONTH, monthCount); // date manipulation
			System.out.println("result: " + df.format(cal.getTime())); // conversion to String
			Maturitydate = df.format(cal.getTime());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return Maturitydate;
	}

	public void mouseActionsClick(WebElement element) throws IOException {
		try {
			Actions actions = new Actions(getDriver());

			actions.moveToElement(element).click().build().perform();
			takeScreenShotForEachTest(testcasedata);
		} catch (Exception e) {
			getScreenshotAs("Screenshot");
			Assert.fail("Unable to click on element " + element + " beacause of exception " + e);
		}
	}

	public static void selectDropDownText(WebElement element, String inputData) throws IOException {
		Boolean flag = false;
		Select dropdown = new Select(element);
		if (!inputData.equals("")) {
			try {
				dropdown.selectByVisibleText(inputData);
				takeScreenShotForEachTest(testcasedata);
				flag = true;
			} catch (NoSuchElementException NSE) {
				getScreenshotAs("Screenshot");
				System.out.println("Unable to select using drop down value: " + inputData);
			}

			if (!flag) {
				List<WebElement> data = dropdown.getOptions();
				for (WebElement option : data) {
					dropdown.selectByVisibleText(inputData);
					takeScreenShotForEachTest(testcasedata);
				}
			}
		}
	}

	public boolean waitForJQuerytoLoad(int waittime) {
		WebDriverWait wait = new WebDriverWait(getDriver(), waittime);
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		// wait for jQuery to load
		ExpectedCondition<Boolean> jQueryLoad = new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver driver) {
				try {
					return ((Long) js.executeScript("return jQuery.active") == 0);
				} catch (Exception e) {
					try {
						getScreenshotAs("Screenshot");
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					return true;
				}
			}
		};
		return wait.until(jQueryLoad);
	}

	public static  void getScreenshotAs(String screenShotName) throws IOException {
		String dest = null;
        String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
        TakesScreenshot ts = (TakesScreenshot) WebDriverTestBase.getDriver();
        File source = ts.getScreenshotAs(OutputType.FILE);

        dest = System.getProperty("user.dir")+"\\screenshots\\" + screenShotName + dateName + ".png";
        System.out.println(System.getProperty("user.dir"));
        System.out.println(dest);
        File destination = new File(dest);
        FileUtils.copyFile(source, destination);
		Reporter.addScreenCaptureFromPath(dest);
	}

	public void clickUsingJavaScript(WebElement element) throws IOException {
		try {
			JavascriptExecutor executor = (JavascriptExecutor) getDriver();
			executor.executeScript("arguments[0].click();", element);
			takeScreenShotForEachTest(testcasedata);
		} catch (Exception e) {
			getScreenshotAs("Screenshot");
		}
	}

	public static String getDateInString(String dateString) {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-mm-dd");
		String dateInString = dateString;

		try {

			Date date = formatter.parse(dateInString);
			System.out.println(date);
			System.out.println(formatter.format(date));

		} catch (ParseException e) {
			e.printStackTrace();
		}
		return dateInString;
	}

	public static void waitFor3Secs() throws IOException {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			getScreenshotAs("Screenshot");
			e.printStackTrace();
		}
	}

	public static void takeScreenShot(String fileName) {

		// Take screenshot and store as a file format
		File src = ((TakesScreenshot) getDriver()).getScreenshotAs(OutputType.FILE);
		try {
			// now copy the screenshot to desired location using copyFile //method
			FileUtils.copyFile(src, new File("screenshots/" + fileName + ".png"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void takeScreenShotForEachTest(Map<String, Object> testcasedata) {
		if (!takeScreenShotForEachTest.toUpperCase().contains("NO")) {
			try {
				getScreenshotAs("Screenshot");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/*public static String getScreenshot(String screenShotName) throws IOException {
		// below line is just to append the date format with the screenshot name to
		// avoid duplicate names

		String dest = null;
		String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
		TakesScreenshot ts = (TakesScreenshot) getDriver();
		File source = ts.getScreenshotAs(OutputType.FILE);
		System.out.println("source file path is " + source.getAbsolutePath().toString());
		dest = System.getProperty("user.dir") + "\\bin\\screenshots\\" + screenShotName + dateName + ".png";
		// System.out.println(System.getProperty("user.dir"));
		System.out.println(dest);
		File destination = new File(dest);
		FileUtils.copyFile(source, destination);

		// Reporter class is used to attach the screenshot to the extent report
		// Reporter.addScreenCaptureFromPath(".\\screenshots\\" + screenShotName +
		// dateName + ".png");
		Reporter.addScreenCaptureFromPath(dest);

		return destination.getAbsolutePath();
	}*/

	public static String screenShot(String filename) throws IOException, InterruptedException {
		String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
		File scr = ((TakesScreenshot) getDriver()).getScreenshotAs(OutputType.FILE);
		filename = dateName + filename + ".png";
		File dest = new File(".\\screenshots\\" + filename);
		FileUtils.copyFile(scr, dest);

		// Reporter class is used to attach the screenshot to the extent report
		Reporter.addScreenCaptureFromPath(".\\screenshots\\" + filename + ".png");

		return dest.getAbsolutePath();
	}

	public static boolean isElementVisible(WebElement element) throws IOException {
		try {
			new WebDriverWait(getDriver(), 10).until(ExpectedConditions.visibilityOf(element));
			takeScreenShotForEachTest(testcasedata);
			return true;
		} catch (Exception e) {
			getScreenshotAs("Screenshot");
			System.out.println(e.getMessage());
			return false;
		}
	}

	public static boolean isElementClickable(WebElement element) throws IOException {
		try {
			new WebDriverWait(getDriver(), 10).until(ExpectedConditions.elementToBeClickable(element));
			takeScreenShotForEachTest(testcasedata);
			return true;
		} catch (Exception e) {
			getScreenshotAs("Screenshot");
			System.out.println(e.getMessage());
			return false;
		}
	}

	public static boolean switchToFrame(WebElement element) throws IOException {
		try {
			getDriver().switchTo().frame(element);
			takeScreenShotForEachTest(testcasedata);
			return true;
		} catch (NoSuchFrameException e) {
			getScreenshotAs("Screenshot");
			e.printStackTrace();
			return false;
		}
	}

	public static boolean outOfFrame() throws IOException {
		try {
			getDriver().switchTo().defaultContent();
			takeScreenShotForEachTest(testcasedata);
			return true;
		} catch (Exception e) {
			getScreenshotAs("Screenshot");
			e.printStackTrace();
			return false;
		}
	}

	public static boolean switchToChildWindow() throws IOException {
		try {
			// Switch to child window if already on parent window
			String parentWindow = getDriver().getWindowHandle();
			Set<String> childWindows = getDriver().getWindowHandles();
			for (String childWindow : childWindows)
				if (!childWindow.equals(parentWindow)) {
					getDriver().switchTo().window(childWindow);
					takeScreenShotForEachTest(testcasedata);
				}
			return true;
		} catch (NoSuchWindowException e) {
			getScreenshotAs("Screenshot");
			e.printStackTrace();
			return false;
		}
	}

	public static boolean switchToParentWindow() throws IOException {
		try {
			// Switch to parent window if already on child window
			String childWindow = getDriver().getWindowHandle();
			Set<String> windowHandles = getDriver().getWindowHandles();
			for (String parentWindow : windowHandles)
				if (!parentWindow.equals(childWindow)) {
					getDriver().switchTo().window(parentWindow);
					takeScreenShotForEachTest(testcasedata);
				}
			return true;
		} catch (NoSuchWindowException e) {
			getScreenshotAs("Screenshot");
			e.printStackTrace();
			return false;
		}
	}

	public static boolean acceptAlert() throws IOException {
		try {
			// To click on 'OK' button of the alert
			Alert alert = getDriver().switchTo().alert();
			alert.accept();
			takeScreenShotForEachTest(testcasedata);
			return true;
		} catch (NoAlertPresentException e) {
			getScreenshotAs("Screenshot");
			e.printStackTrace();
			return false;
		}
	}

	public static boolean dismissAlert() throws IOException {
		try {
			// To click on 'Cancel' button of the alert
			Alert alert = getDriver().switchTo().alert();
			alert.dismiss();
			takeScreenShotForEachTest(testcasedata);
			return true;
		} catch (NoAlertPresentException e) {
			getScreenshotAs("Screenshot");
			e.printStackTrace();
			return false;
		}
	}

	public static boolean getAlertMessage() throws IOException {
		try {
			// To capture the alert message
			Alert alert = getDriver().switchTo().alert();
			takeScreenShotForEachTest(testcasedata);
			return true;
		} catch (NoAlertPresentException e) {
			getScreenshotAs("Screenshot");
			e.printStackTrace();
			return false;
		}
	}

	public static void sendKeysAlertBox(String value) throws IOException {
		try {
			// To send some data to alert box
			Alert alert = getDriver().switchTo().alert();
			alert.sendKeys(value);
			takeScreenShotForEachTest(testcasedata);
		} catch (NoAlertPresentException e) {
			getScreenshotAs("Screenshot");
			e.printStackTrace();
		}
	}
	
	public static int datecompare(String date1,String date2,String date3) throws ParseException
   	{
   		
    	//System.out.println("Executing the datecompare method");
   		Date date_from = new SimpleDateFormat("yyyy/MMM/dd").parse(date1);
   		Date date_to = new SimpleDateFormat("yyyy/MMM/dd").parse(date2);
   		Date date_filter = new SimpleDateFormat("yyyy/MMM/dd").parse(date3);
   		
   		//System.out.print(date_from);
   		//System.out.print(date_to);
   		//System.out.print(date_filter);
   		
   		if(date_filter.before(date_from) || date_filter.after(date_to) )
   		{
   			return 0;
   		}
   		else return 1;  		   		
   		
   	}
	
	public static void equalText(WebElement element, String ExpectedErrormsg, String attType) throws IOException {
        
        String actualmsg = "";
        if(attType.equalsIgnoreCase("TEXT"))
               actualmsg = element.getText();
        else if(attType.equalsIgnoreCase("VALUE"))
               actualmsg = element.getAttribute("value");
        
        if (!actualmsg.equals(ExpectedErrormsg)) {
               getScreenshotAs("Screenshot");
               Assert.fail("Maintenance is not done as expected message is " + ExpectedErrormsg
                            + " Actual Message is mis-matched : " + actualmsg);
        }
        else
               takeScreenShotForEachTest(testcasedata);
               
 }

}
