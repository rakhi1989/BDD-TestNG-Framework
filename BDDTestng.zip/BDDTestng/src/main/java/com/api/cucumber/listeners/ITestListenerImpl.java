package com.api.cucumber.listeners;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;



public class ITestListenerImpl extends ExtentReportListener implements ITestListener {
	
	static boolean isStepFailed = false;
	
	@Override
	public void onFinish(ITestContext arg0) {
		System.out.println("Execution is generated on QA Environment");
		System.out.println("Generated Report....");
		FlushReport();
		
	}

	@Override
	public void onStart(ITestContext arg0) {
		System.out.println("Execution is started on QA Environment");
		final Properties properties = new Properties();
		 try {
			properties.load(new FileInputStream(".\\src\\main\\java\\utils\\config\\config.properties"));
			String reportname = properties.getProperty("reportname");
            String projectname = properties.getProperty("projectname");
            String user = properties.getProperty("user");
            
            setUp(reportname,projectname,user);
            
            CreateTest("Sample Testcase", " Run TestCase sample testcase end to end .");
            
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		 
}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onTestFailure(ITestResult iTestResult) {
		System.out.println("FAIL");
		try{
			StepFail("Test " + iTestResult.getName() + " failed");
        } catch (IOException e) {
            e.printStackTrace();
        }
		
	}

	@Override
	public void onTestSkipped(ITestResult arg0) {
		System.out.println("SKIP");
		
	}

	@Override
	public void onTestStart(ITestResult testResult) {
		//CreateTest(testResult.getTestName(), " Run TestCase " + testResult.getTestName() + " end to end .");
		
		
	}

	@Override
	public void onTestSuccess(ITestResult iTestResult) {
		System.out.println("PASS");
	try{	
		StepPass("Test " + iTestResult.getName() + " passed");
    } catch (IOException e) {
        e.printStackTrace();
    }
		
	}

}
