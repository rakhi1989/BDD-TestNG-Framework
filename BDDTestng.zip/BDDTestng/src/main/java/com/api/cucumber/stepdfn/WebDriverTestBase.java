package com.api.cucumber.stepdfn;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.testng.CucumberFeatureWrapper;
import cucumber.api.testng.TestNGCucumberRunner;
import cucumber.runtime.model.CucumberTagStatement;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.SkipException;
import org.testng.annotations.Parameters;
import com.relevantcodes.extentreports.LogStatus;
import com.api.cucumber.readexcel.ExcelReader;
import com.api.cucumber.runner.TestRunner;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class WebDriverTestBase {


	protected static String takeScreenShotForEachTest;
	protected static String driver_path;
	protected static String executionMode;
	protected static String execution_Environment;
	protected static String execution_Grid;
	protected static String execution_Tool;
	protected static String applocation_Type;
	protected static String closeBrowserEachTest;
	protected static String reportConfigPath;
	private static ThreadLocal<WebDriver> threadSafeDriver = new ThreadLocal<WebDriver>();
	public static boolean isDriverAlive = false;
	public static String act_ScenarioName = TestRunner.act_ScenarioName;
	public static String exp_Scenario = TestRunner.exp_Scenario;
	
	
	
	@Before
	public  void setUp() throws IOException, InterruptedException {
		Properties Config = new Properties();
		FileInputStream file = new FileInputStream(".\\src\\main\\java\\utils\\config\\config.properties");
		Config.load(file);
		takeScreenShotForEachTest = Config.getProperty("takeScreenShotForEachStep");
		driver_path = Config.getProperty("driver_path");
		executionMode = Config.getProperty("ExecutionMode");
		closeBrowserEachTest = Config.getProperty("closeBrowserForEachTest");
		reportConfigPath = Config.getProperty("reportConfigPath");
		if (!isDriverAlive) {
			launchBrowser(Config.getProperty("browser"), Config.getProperty("url"));
			isDriverAlive = true;
		}
	
	  
	}


	public static WebDriver getDriver() {
		return threadSafeDriver.get();
		
	}

	public static void launchBrowser(String browserType, String url) {

		switch (browserType.toUpperCase()) {
		case "CHROME":
			setChromeDriverProperty();
			ChromeOptions options = new ChromeOptions();
		    options.setExperimentalOption("useAutomationExtension", false);
			threadSafeDriver.set(new ChromeDriver(options));
			break;
		case "FIREFOX":
			setFirefoxDriverProperty();
			threadSafeDriver.set(new FirefoxDriver());
			break;
		case "IE":
			setIEDriverProperty();
			threadSafeDriver.set(new InternetExplorerDriver());
			break;
		case "EDGE":
			setIEDriverProperty();
			threadSafeDriver.set(new InternetExplorerDriver());
			break;
		default:
			break;

		}
		threadSafeDriver.get().manage().window().maximize();
		threadSafeDriver.get().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		threadSafeDriver.get().get(url);
		
	}

	private static void setChromeDriverProperty() {
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + File.separator + driver_path);
	}

	private static void setFirefoxDriverProperty() {
		System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + File.separator + driver_path);
	}

	private static void setIEDriverProperty() {
		System.setProperty("webdriver.ie.driver", System.getProperty("user.dir") + File.separator + driver_path);
	}

	
	
	
	public static String getReportConfigPath() throws IOException {
		Properties Config = new Properties();
		FileInputStream file = new FileInputStream(".\\src\\main\\java\\utils\\config\\config.properties");
		Config.load(file);
		String reportConfigPath = Config.getProperty("reportConfigPath");
		if (reportConfigPath != null)
			return reportConfigPath;
		else
			throw new RuntimeException(
					"Report Config Path not specified in the config.properties file for the Key:reportConfigPath");
	}
}
