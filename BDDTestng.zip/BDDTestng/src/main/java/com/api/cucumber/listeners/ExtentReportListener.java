package com.api.cucumber.listeners;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import utils.libraries.common.Log;

import com.api.cucumber.stepdfn.WebDriverTestBase;

public class ExtentReportListener {
	
	public static ExtentHtmlReporter report = null;
	public static ExtentReports extent = null;
	public static ExtentTest test = null;
	
	public static void setUp(String reportname,String projectname,String user){
		//String reportLocation = "C:\\ACOE\\BDDTestng\\testreports\\Extent_Report.html";
		System.out.println("Initializing The Extent Report Location");
		
		extent = new ExtentReports();
		report = new ExtentHtmlReporter(reportname+ ".html");
		extent.attachReporter(report);
		extent.setSystemInfo("Application","RisrDB");
		extent.setSystemInfo("User",user);
		extent.setSystemInfo("Operating System",System.getProperty("os.name"));
		System.out.println("System Info. set in Extent Report");
		
	}
	
	 public void CreateTest(String TestCaseName, String Description) {
	        if (extent != null) {
	            test = extent.createTest(TestCaseName, Description);
	        }
	    }
	 
	 public void StepPass(String Description) throws IOException {
	        String ExtentPassStepScreenPath=getScreenshot("Screenshot");
	        Log.info("The screenshot file path is " + ExtentPassStepScreenPath);
	        if (ExtentPassStepScreenPath != null) {

	            if (test != null)
	                test.pass("Pass - " + Description, MediaEntityBuilder
	                        .createScreenCaptureFromPath(ExtentPassStepScreenPath).build());
	        }
	        else if (test != null)
	            test.pass("Pass - " + Description);
	    }
	 
	 public void FlushReport() {
	        if (extent != null)
	            extent.flush();
	    }
	 
	 public void StepFail(String Description) throws IOException {
	        String ExtentFailStepScreenPath = getScreenshot(Description+"Screenshot");
	        Log.info("The screenshot file path is " + ExtentFailStepScreenPath);
	        System.out.println("THe extent fail step screen path: "+ExtentFailStepScreenPath);

	        if (ExtentFailStepScreenPath != null) {
	            if (test != null)
	                test.fail("Fail - " + Description, MediaEntityBuilder
	                        .createScreenCaptureFromPath(ExtentFailStepScreenPath).build());
	        } else if (test != null)
	            test.fail("Fail - " + Description);
	    }
	
	public static void testStepHandle(String teststatus,WebDriver driver,ExtentTest extenttest,Throwable throwable){
		switch(teststatus){
		case "FAIL":
			extenttest.fail(MarkupHelper.createLabel("Test case step is Failed :",ExtentColor.RED));
			extenttest.error(throwable.fillInStackTrace());
			if(driver != null){
				driver.quit();
			}
			break;
		case "PASS":
			extenttest.pass(MarkupHelper.createLabel("Test case step is Passed :",ExtentColor.GREEN));
			break;
		default:
			break;
		}
			
		}
	
	public static String getScreenshot(String screenShotName) throws IOException {
        //below line is just to append the date format with the screenshot name to avoid duplicate names
        String dest = null;
        String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
        TakesScreenshot ts = (TakesScreenshot) WebDriverTestBase.getDriver();
        File source = ts.getScreenshotAs(OutputType.FILE);

        dest = System.getProperty("user.dir")+"\\screenshots\\" + screenShotName + dateName + ".png";
        System.out.println(System.getProperty("user.dir"));
        System.out.println(dest);
        File destination = new File(dest);
        FileUtils.copyFile(source, destination);

        return destination.getAbsolutePath();
    }
	}

