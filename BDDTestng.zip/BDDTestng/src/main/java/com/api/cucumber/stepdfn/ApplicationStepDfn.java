package com.api.cucumber.stepdfn;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.api.cucumber.listeners.ExtentReportListener;
import com.api.cucumber.pageobjects.Users;
import com.api.cucumber.readexcel.*;
import com.api.cucumber.runner.TestRunner;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import com.api.cucumber.stepdfn.WebDriverTestBase;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.GherkinKeyword;
import com.aventstack.extentreports.gherkin.model.Feature;
import com.aventstack.extentreports.gherkin.model.Scenario;
import com.api.cucumber.pageobjects.Users;

public class ApplicationStepDfn extends ExtentReportListener {
	
	public static Map<String, Object> testcasedata =ExcelReader.mapvalues;
	Users users = new Users(WebDriverTestBase.getDriver());
	//public static boolean IsSkipScenario = TestRunner.IsSkipScenario;
	
	public ApplicationStepDfn() throws IOException {
	}
	
	@Given("^User is at the login page of the application$")
	public void user_is_at_the_login_page_of_the_application() throws Throwable {
	}

	@And("^I navigate to Add User Page$")
	public void i_navigate_to_Add_User_Page() throws Throwable {
		users.NavigateAddUserPage(testcasedata);
	}
	
	@And("^I validate the Mandatory fields$")
	public void i_validate_the_Mandatory_fields() throws Throwable {
		users.VerifyMandatoryFields(testcasedata);
		
	}
	@And("^I enter all the user details$")
	public void i_enter_all_the_user_details() throws Throwable {
		users.AddUserandSearch(testcasedata);
		users.VerifySearchResult(testcasedata);
			
	}
	
	@And("^I navigate to Administration Page and search for user$")
	public void i_navigate_to_Administration_Page_and_search_for_user() throws Throwable {
		users.NavigateAdministrationPage(testcasedata);
		
	}

	
	@And("^I update the user details$")
	public void i_update_the_user_details() throws Throwable {
		users.UpdateUserandSearch(testcasedata);
		
	}


}
