package com.api.cucumber.pageobjects;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.api.cucumber.runner.TestRunner;

import utils.libraries.common.Helper;
//import utils.libraries.common.Log;
import utils.libraries.common.Log;

public class Users extends PageObject {

	// RISRDB : Add User : header tab object
	@FindBy(xpath = "//*[@id='security']")
	private WebElement maintab_Administration;

	// RISRDB : Add User : page tab object
	@FindBy(xpath = "//*[@id='MainTabContainer_tablist_tab1']")
	private WebElement pagetab_Users;

	// RISRDB : Add User : Add User button object
	@FindBy(xpath = "//*[@id='dijit_form_Button_2_label']")
	private WebElement addUser;

	// RISRDB : Add User : submit button object
	@FindBy(xpath = "//*[@id='submitNewUser_label']")
	private WebElement submit_Add_User;

	// RISRDB : Add User : error message area object
	@FindBy(xpath = "//*[@id='messageManagerArea']")
	private WebElement ValidationMsgAddUser;

	// RISRDB : Add User : Network ID object
	@FindBy(xpath = "//*[@id='User_NetworkId']")
	private WebElement addUser_NetworkID;

	// RISRDB : Add User : Security Role object
	@FindBy(xpath = "//*[@id='User_SecurityGroupId']")
	private WebElement addUser_Security_Role;

	public String securityRole_value = "//table[@id='User_SecurityGroupId_menu']/tbody/tr/td[@class='dijitReset dijitMenuItemLabel' and starts-with(text(),'$giveVal')]";

	// RISRDB : Add User : Search screen Network ID object
	@FindBy(xpath = "//*[@id='SearchUser_Entity_NetworkId']")
	private WebElement searchUserwithNetworkId;

	// RISRDB : Add User : Search button object
	@FindBy(xpath = "//*[@id='dijit_form_Button_0_label']")
	private WebElement searchUserbtn;

	// RISRDB : Add User : Search User Value object
	@FindBy(xpath = "//*[@id='userTable']/tbody/tr[1]/td[6]")
	private WebElement searchUser;

	// RISRDB : Update User : Search User Value object
	@FindBy(xpath = "//*[@id='submitUpdateUser_label']")
	private WebElement saveUser;

	@FindBy(xpath = "//*[@id='userTablenoRecordsLabel']")
	private WebElement NoRecordFound;

	@FindBy(xpath = "//*[@id='labelUser_NetworkId']")
	private WebElement label_NetworkId;
	
	public Users(WebDriver driver) throws IOException {
		super(driver);
	}
	
	public WebElement prepareWebElementWithDynamicXpath(String xpathValue, String substitutionValue) {
		return driver.findElement(By.xpath(xpathValue.replace("$giveVal", substitutionValue)));
	}
	String SuccessMsgvalue;
	public void AddUserandSearch(Map<String, Object> testcasedata) throws InterruptedException, AWTException, IOException {
		
				Helper.click(addUser_NetworkID,testcasedata);
				String expected_NetworkID_value = String.valueOf(testcasedata.get("NetworkId"));
				// testcasedata.keySet();
				Helper.clearAndEnterText(addUser_NetworkID, expected_NetworkID_value);
				Robot robot = new Robot();
				robot.keyPress(KeyEvent.VK_TAB);
				Thread.sleep(3000);
				SuccessMsgvalue = Helper.getText(ValidationMsgAddUser, testcasedata);

				if (SuccessMsgvalue.contains("That User Id is already assigned in the system")) {
					// Log.info(SuccessMsgvalue);
					Assert.fail("That User Id is already assigned in the system");

				}

				else {
					Helper.click(addUser_Security_Role, testcasedata);
					String expected_search_Security_Role = String.valueOf(testcasedata.get("SecurityGroupId"));
					WebElement SecurityRole = prepareWebElementWithDynamicXpath(securityRole_value,
							expected_search_Security_Role);
					Helper.click(SecurityRole, testcasedata);

					Helper.click(submit_Add_User, testcasedata);
					Thread.sleep(3000);
				}
		
		String SuccessMsgvalue1 = Helper.getText(ValidationMsgAddUser, testcasedata);
		
		if (SuccessMsgvalue1.contains("User Added")) {
			Thread.sleep(1000);
			Helper.click(maintab_Administration, testcasedata);
			Helper.click(pagetab_Users, testcasedata);

			Helper.click(searchUserwithNetworkId, testcasedata);
			String expected_search_Network_Id = String.valueOf(testcasedata.get("NetworkId"));
			Helper.clearAndEnterText(searchUserwithNetworkId, expected_search_Network_Id);

			Helper.click(searchUserbtn, testcasedata);
			
			Helper.click(searchUser, testcasedata);

			Thread.sleep(1000);
		} else {
		}

	}

	public void NavigateAddUserPage(Map<String, Object> testcasedata) throws InterruptedException, AWTException, IOException {
		String main_tab_Administration = Helper.getText(maintab_Administration, testcasedata);
		System.out.println("main tab name is   "+main_tab_Administration);
		Log.info(main_tab_Administration);
		Helper.click(maintab_Administration, testcasedata);

		String page_tab_user = Helper.getText(pagetab_Users, testcasedata);
		System.out.println("no of users is users tab   "+page_tab_user);
		Log.info(page_tab_user);
		Helper.click(pagetab_Users, testcasedata);

		String add_User = Helper.getText(addUser, testcasedata);
		Log.info(add_User);
		Helper.click(addUser, testcasedata);

	}
	
	public void NavigateAdministrationPage(Map<String, Object> testcasedata) throws InterruptedException, AWTException, IOException {
		String main_tab_Administration = Helper.getText(maintab_Administration, testcasedata);
		System.out.println("main tab name is   "+main_tab_Administration);
		Log.info(main_tab_Administration);
		Helper.click(maintab_Administration, testcasedata);

		String page_tab_user = Helper.getText(pagetab_Users, testcasedata);
		System.out.println("no of users is users tab   "+page_tab_user);
		Log.info(page_tab_user);
		Helper.click(pagetab_Users, testcasedata);


	}
	
	// Update User scenario
	public void UpdateUserandSearch(Map<String, Object> testcasedata) throws InterruptedException, IOException {
			
			Helper.click(searchUserwithNetworkId, testcasedata);
			String expected_search_Network_Id = String.valueOf(testcasedata.get("NetworkId"));
			Helper.clearAndEnterText(searchUserwithNetworkId, expected_search_Network_Id);

			Thread.sleep(3000);

			Helper.click(searchUserbtn, testcasedata);
			Helper.click(searchUser, testcasedata);

			Helper.click(addUser_Security_Role, testcasedata);
			String expected_search_Security_Role = String.valueOf(testcasedata.get("SecurityGroupId"));
			WebElement SecurityRole = prepareWebElementWithDynamicXpath(securityRole_value, expected_search_Security_Role);
			Helper.click(SecurityRole, testcasedata);

			Helper.click(saveUser, testcasedata);

			String SuccessMsgvalue = Helper.getText(ValidationMsgAddUser, testcasedata);
			Log.info(SuccessMsgvalue);

			if (SuccessMsgvalue.contains("User has been updated")) {
				Thread.sleep(1000);
				Helper.click(maintab_Administration, testcasedata);
				Helper.click(pagetab_Users, testcasedata);

				Helper.click(searchUserwithNetworkId, testcasedata);
				String expected_search_Network_Id1 = String.valueOf(testcasedata.get("NetworkId"));
				Helper.clearAndEnterText(searchUserwithNetworkId, expected_search_Network_Id1);

				Helper.click(searchUserbtn, testcasedata);
				Log.info("Searching Updated User");

				Helper.click(searchUser, testcasedata);

				Thread.sleep(500);
			} else {
				Log.info("User has not updated");
			}
		}
		
		
	public void VerifyMandatoryFields(Map<String, Object> testcasedata) throws InterruptedException, AWTException, IOException {
		
		Helper.click(submit_Add_User, testcasedata);

		String addUserNetworkIDValue = Helper.getText(addUser_NetworkID, testcasedata);
		String addUserSecurityRoleValue = Helper.getText(addUser_Security_Role, testcasedata);
		String validationMsgAddUserValue = Helper.getText(ValidationMsgAddUser, testcasedata);

		if (addUserNetworkIDValue.isEmpty() || addUserSecurityRoleValue.isEmpty()) {
			if (validationMsgAddUserValue.contains("Please review all highlighted fields before continuing")) {

				String[] Expected_Mandatory = RequiredFields.ExpectedMandatory(testcasedata);
				int expectedSize = Expected_Mandatory.length;

				List<WebElement> element = driver.findElements(By.xpath("//*[contains(@aria-required,'true')]"));
				int count = element.size();
				int actualCount = 0;
				int valueCount;
				String[] Actual_Mandatory = new String[count];

				for (int j = 0; j < count; j++) {
					Actual_Mandatory[j] = element.get(j).getAttribute("id");
				}
				for (int r = 0; r < count; r++) {
					valueCount = 0;
					for (int s = 0; s < expectedSize; s++) {
						if (Actual_Mandatory[r].contains(Expected_Mandatory[s])) {
							// Log.info(Actual_Mandatory[r]+ "--> Required field
							// is matched");
							actualCount++;
							valueCount++;
							break;
						}

					}
					if(valueCount == 0)
					{
						Log.info(Actual_Mandatory[r]+ "--> Required field is not matched");
					}
				}

				if (actualCount == count) {
					Log.info("Mandatory fields are matched");
				}else {
					Log.info("Mandatory fields are not matched");
				}

				}
		}
	}
	
	public void VerifySearchResult(Map<String, Object> testcasedata) throws InterruptedException {

		if (SuccessMsgvalue.contains("That User Id is already assigned in the system")) {
			Log.info("Verification cannot be proceeded further as User is not added");
		}

		else {
			String verifyNetworkID = addUser_NetworkID.getAttribute("value");
			String expected_network_id_value = String.valueOf(testcasedata.get("NetworkId"));

			if (verifyNetworkID.equals(expected_network_id_value)) {
				Log.info("Network ID matched");
			} else {
				Log.info("Network ID not matched");
			}

			String verifysecurityRole = addUser_Security_Role.getText();
			String expected_security_role_value = String.valueOf(testcasedata.get("SecurityGroupId"));

			if (verifysecurityRole.equals(expected_security_role_value)) {
				Log.info("Security Role matched");
			} else {
				Log.info("Security Role not matched");
			}

			Log.info("Validation Completed");
		}
	}
	

	}