package com.api.cucumber.runner;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import com.api.cucumber.readexcel.ExcelReader;
import com.api.cucumber.stepdfn.WebDriverTestBase;
import com.vimalselvam.cucumber.listener.Reporter;
import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;
import cucumber.api.testng.CucumberFeatureWrapper;
import cucumber.api.testng.TestNGCucumberRunner;
import cucumber.runtime.model.CucumberTagStatement;

@CucumberOptions(
		features={"src/main/java/com/api/cucumber/featurefile"},
		glue = {"com.api.cucumber.stepdfn"},
		plugin = {"com.vimalselvam.cucumber.listener.ExtentCucumberFormatter:testreports/Extent_Report.html"}
		)
@Listeners(com.api.cucumber.listeners.ITestListenerImpl.class)
public class TestRunner extends AbstractTestNGCucumberTests {
	
	private TestNGCucumberRunner tcr;
	public static String filePath = System.getProperty("user.dir")+"\\testdata\\TestData.xlsx";
	public static String SheetName = "Users";
	public static ArrayList<Integer> testdatarowcount = new ArrayList<Integer>();
	public static  Map<String,Object> testcasedata = new HashMap<String,Object>();
	public static CucumberTagStatement tagStatement = null;
	public static String act_ScenarioName = null;
	public static String exp_Scenario = null;
	public static String FeatureName = null;
	protected static String closeBrowserEachTest;
	protected static String  reportname;
	protected static String  projectname;
	protected static String  application;
	
    @BeforeClass(alwaysRun=true)
    public void beforeClass() throws Exception{
        tcr = new TestNGCucumberRunner(this.getClass());
        testdatarowcount = ExcelReader.getRowCount(filePath,SheetName);
        final Properties properties = new Properties();
		 try {
			properties.load(new FileInputStream(".\\src\\main\\java\\utils\\config\\config.properties"));
			closeBrowserEachTest = properties.getProperty("closeBrowserForEachTest");
			reportname = properties.getProperty("reportname");
			projectname = properties.getProperty("projectname");
			application = properties.getProperty("application");
		 } catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	}

    @Test(groups="cucumber", description="Runs CucumberFeature", dataProvider="features")
    public void feature(CucumberFeatureWrapper cucumberFeature){
    	for(int i=0; i<testdatarowcount.size(); i++){
    			int row = testdatarowcount.get(i);
				testcasedata = ExcelReader.getSingleRowTestCaseData(row);
				exp_Scenario = String.valueOf(testcasedata.get("Scenario"));
				FeatureName = cucumberFeature.toString();
				/*for(CucumberTagStatement tagStatement : cucumberFeature.getCucumberFeature().getFeatureElements()){
					//List<Tag> tags = tagStatement.getGherkinModel().getTags();
					act_ScenarioName = tagStatement.getGherkinModel().getName();
					}*/
				
				if(FeatureName.contains(exp_Scenario)){
					tcr.runCucumber(cucumberFeature.getCucumberFeature());
					System.out.println(FeatureName);
				}
				else{
					System.out.println(exp_Scenario);
					System.out.println(FeatureName);
				}
			}
		}



    @DataProvider
    public Object[][] features(){
    	return tcr.provideFeatures();
    }
    
   /* @AfterTest (alwaysRun = true)
    public void quiteDriver(){
    	if (closeBrowserEachTest.toUpperCase().contains("YES")) {
    				if (WebDriverTestBase.isDriverAlive) {
    					//getDriver().close();
    					WebDriverTestBase.getDriver().quit();
    					WebDriverTestBase.isDriverAlive = false;
    					
    				}
    			}
    }*/

    @AfterClass (alwaysRun=true)
    public void afterClass() throws IOException, InterruptedException{
    	
    	if (closeBrowserEachTest.toUpperCase().contains("YES")) {
			if (WebDriverTestBase.isDriverAlive) {
				//getDriver().close();
				WebDriverTestBase.getDriver().quit();
				WebDriverTestBase.isDriverAlive = false;
				
			}
		}
    	System.out.println("Report creation has been started");    	
    	Reporter.loadXMLConfig(new File(WebDriverTestBase.getReportConfigPath()));
    	
    	/*Reporter.setSystemInfo("Application","RisrDB_123");
    	Reporter.setSystemInfo("Operating System",System.getProperty("os.name"));*/
    	//System.out.println("check it is loaded or not"); 
		Reporter.setSystemInfo("User Name", System.getProperty("user.name"));
        Reporter.setSystemInfo("Time Zone", System.getProperty("user.timezone"));
        Reporter.setSystemInfo("Report Name", reportname);
        Reporter.setSystemInfo("Project Name", projectname);
        Reporter.setSystemInfo("Application Name", application);
        Reporter.setTestRunnerOutput("Sample Test runner output message");
        
        tcr.finish();
        
        BasicFileAttributes attrs;
        String sourceFile = System.getProperty("user.dir") + "\\testreports\\Extent_Report.html";
        File source = new File(sourceFile);
        attrs = Files.readAttributes(source.toPath(), BasicFileAttributes.class);
        FileTime time = attrs.creationTime();               
        String pattern = "yyyy-MMM-dd-HHmmss";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);                
        String dateName = simpleDateFormat.format( new Date( time.toMillis() ) );
        String dest = System.getProperty("user.dir") + "\\testreports\\Extent_Report" + "_" + dateName + ".html";
        File destination = new File(dest);
        source.renameTo(destination);
          
        
        
     }

}
