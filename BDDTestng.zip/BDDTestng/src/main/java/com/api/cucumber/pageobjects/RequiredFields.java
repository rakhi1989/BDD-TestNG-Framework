package com.api.cucumber.pageobjects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class RequiredFields {

	public static String[] ExpectedMandatory(Map<String, Object> testcasedata) {
		Set<String> Keys = testcasedata.keySet();
		int size = Keys.size();
		String[] Mandatory = new String[size];
		int i = 0;
		for (Map.Entry mapElement : testcasedata.entrySet()) { 
            String key = (String)mapElement.getKey(); 
  
            // Add some bonus marks 
            // to all the students and print it 
            String value = (String) mapElement.getValue(); 
            
           if (value.contains("REQ")){
        	   Mandatory[i] = key;
				++i;
           }
		} 
		
		List<String> list = new ArrayList<String>();
		for(String s : Mandatory) {
	       if(s != null && s.length() > 0) {
	          list.add(s);
	       }
	    }
		Mandatory = list.toArray(new String[list.size()]);
		return Mandatory; 


	}
	
	public static String[] ExpectedMandatory1(Map<String, Object> testcasedata) {
		Set<String> Keys = testcasedata.keySet();
		int size = Keys.size();
		String[] Mandatory = new String[size];
		int i = 0;
		//System.out.println("inside the expected mandatory loop");
		for (String key : Keys) {
			// String[] split_req = key.split("@");

			// System.out.println(split_req);
			if (key.startsWith("REQ_")) {
				String s1 = key.substring(4);

				if (s1.contains("_")) {
					String s2 = s1.replaceAll("_", " ");
					Mandatory[i] = s2;
					++i;
				} else {
					Mandatory[i] = s1;
					++i;
				}
			}

		}

		// int MSize = Mandatory.length;
		List<String> list = new ArrayList<String>();

		for (String s : Mandatory) {
			if (s != null && s.length() > 0) {
				list.add(s);
			}
		}

		String[] array = new String[list.size()];
		int index = 0;
		for (Object value : list) {
			array[index] = (String) value;
			index++;
		}

		/*
		 * for(int m=0;m<array.length; m++) { System.out.println(array[m]); }
		 */

		return array;

	}
}
