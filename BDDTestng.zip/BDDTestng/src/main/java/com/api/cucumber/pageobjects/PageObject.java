package com.api.cucumber.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import utils.libraries.common.CustomAssertion;


public class PageObject {
    protected WebDriver driver;
    public CustomAssertion assersion ;

    public PageObject(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver, this);
        assersion = new CustomAssertion();
    }
}
