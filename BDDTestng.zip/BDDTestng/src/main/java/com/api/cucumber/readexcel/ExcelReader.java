package com.api.cucumber.readexcel;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader {
	
	public static Workbook wb;
	public static Sheet ws;
	public static  Map<String,Object> mapvalues = new HashMap<String,Object>();
	public static ArrayList<Integer> getRowCount(String filepath , String SheetName) throws IOException{
		
		ArrayList<Integer> rowno = new ArrayList<Integer>();
		File file =    new File(filepath);
		FileInputStream inputStream = new FileInputStream(file);
	 
		
		//Find the file extension by spliting file name in substing and getting only extension name
		String fileExtensionName = filepath.substring(filepath.indexOf("."));
	 
		//Check condition if the file is xlsx file
		if(fileExtensionName.equals(".xlsx")){
				//If it is xlsx file then create object of XSSFWorkbook class
				wb = new XSSFWorkbook(inputStream);
		}
   
		//Check condition if the file is xls file
		else if(fileExtensionName.equals(".xls")){
			//If it is xls file then create object of XSSFWorkbook class
			wb = new HSSFWorkbook(inputStream);
		}
   
		//Read sheet inside the workbook by its name
		ws = wb.getSheet(SheetName);
		System.out.println(ws.getLastRowNum());
		System.out.println(ws.getFirstRowNum());
		int datarowCount = ws.getLastRowNum()-ws.getFirstRowNum();
		int i = 0;
		for (int rowcount = 0; rowcount < datarowCount; rowcount++) {
			//Loop over all the rows
				Row drow = ws.getRow(rowcount+1);
				Row headerrow = ws.getRow(0);
				if(headerrow.getCell(0).toString().contains("Run") ) {
					if(drow.getCell(0).toString().contains("Y")) {
						rowno.add(drow.getRowNum());
					}
				}
			}
		return rowno;
	}
	
	 public static Map<String, Object> getSingleRowTestCaseData(int rownumber) {
		 
	         	Row drow =  ws.getRow(rownumber);
	         	Row headerlabel = ws.getRow(0);
	            int colCount = headerlabel.getLastCellNum();
	            //int columndata = 0;
	            for (int colIndex = 1; colIndex < colCount; colIndex++) {
	                Cell currentCell = drow.getCell(colIndex);
	                Cell headertext = headerlabel.getCell(colIndex);
	                if (!(currentCell == null)) {
	                    if (currentCell.getCellType() == Cell.CELL_TYPE_STRING) {
	                        mapvalues.put(headertext.getStringCellValue(), currentCell.getStringCellValue());
	                    } else if (currentCell.getCellType() == Cell.CELL_TYPE_NUMERIC) {
	                        mapvalues.put(headertext.getStringCellValue(), currentCell.getNumericCellValue());
	                    } else if (currentCell.getCellType() == Cell.CELL_TYPE_BOOLEAN) {
	                        mapvalues.put(headertext.getStringCellValue(), currentCell.getBooleanCellValue());
	                    }  
	                }
	                if (currentCell.getStringCellValue().equalsIgnoreCase("EndofTest")
	                        || currentCell.getStringCellValue().equalsIgnoreCase("EndofScenario")) {
	                   
	                    break;
	                }
	                //columndata++;
	                
	            }
	            return mapvalues;
	    }

	
}
